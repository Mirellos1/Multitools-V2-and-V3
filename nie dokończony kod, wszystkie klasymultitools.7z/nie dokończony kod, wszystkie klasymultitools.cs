1. Multitools.csproj  Wzór kodu: "

<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>netstandard2.0</TargetFramework>
    <AssemblyName>MultiTools</AssemblyName>
    <RootNamespace>com.My.MultiTools</RootNamespace>
    <LangVersion>9</LangVersion>
    <AppendTargetFrameworkToOutputPath>false</AppendTargetFrameworkToOutputPath>
  </PropertyGroup>

  <ItemGroup>

    <Compile Include="Source\BaseBuilderToolV2\BaseBuilderToolV2.cs" />
    <Compile Include="Source\BaseBuilderToolV2\BaseBuilderToolV2Config.cs" />
    <Compile Include="Source\BaseBuilderToolV3\BaseBuilderToolV3.cs" />
    <Compile Include="Source\BaseBuilderToolV3\BaseBuilderToolV3Config.cs" />
    <Compile Include="Source\BuilderV2\BuilderV2.cs" />
    <Compile Include="Source\BuilderV3\BuilderV3.cs" />
    <Compile Include="Multitools\com.My.MultiTools.cs" />
    <Compile Include="Source\Language\LanguageHandler.cs" />
    <Compile Include="Source\Mod\Main.cs" />
    <Compile Include="Source\Mod\ModConfig.cs" />
    <Compile Include="Source\Mod\ModEnums.cs" />
    <Compile Include="Source\Mod\ModHooks.cs" />
    <Compile Include="Multitools\MultiTools.cs" />
  </ItemGroup>

  <ItemGroup>
    <None Include="Assets\BaseBuilderToolV2.cfg" />
    <None Include="Assets\BaseBuilderToolV3.cfg" />
    <None Include="Assets\MultiTools.cfg" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\BepInEx\BepInEx.csproj">
      <Project>{DE18120F-C341-48A8-BB5B-BB846CF554CF}</Project>
      <Name>BepInEx</Name>
    </ProjectReference>
  </ItemGroup>

  <ItemGroup>
    <Reference Include="Assembly-CSharp">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\Assembly-CSharp.dll</HintPath>
    </Reference>
    <Reference Include="Assembly-CSharp-firstpass">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\Assembly-CSharp-firstpass.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.CoreModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.CoreModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.UI">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.UI.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.PhysicsModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.PhysicsModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.AnimationModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.AnimationModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.InputLegacyModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.InputLegacyModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.CoreModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.CoreModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.InputSystem">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.InputSystem.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.InputSystem.Core">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.InputSystem.Core.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.InputSystem.Extensions">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.InputSystem.Extensions.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.PhysicsModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.PhysicsModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.UI">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.UI.dll</HintPath>
    </Reference>
  </ItemGroup>
</Project>  

   "

2.    com.My.MultiTools.cs Wzór kodu: " 

using BepInEx;
using HarmonyLib;
using SMLHelper.V2.Handlers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Mime;
using HarmonyLib;
using UnityEngine;

namespace MultiTools
{
    [BepInPlugin("com.My.MultiTools", "MultiTools", "1.0.0")]
    [BepInProcess("Subnautica.exe")]
    public class MultiToolsPlugin : BaseUnityPlugin
    {
        private static TechType baseBuilderV2TechType;
        private static TechType baseBuilderV3TechType;

        private void Awake()
        {
            baseBuilderV2TechType = TechTypeHandler.AddTechType("BaseBuilderV2", "Advanced base building tool that can recover basic materials from wrecks", true);
            baseBuilderV3TechType = TechTypeHandler.AddTechType("BaseBuilderV3", "Ultimate base building tool that can randomly recover 1-3 materials", true);

            var harmony = new Harmony("com.My.MultiTools");
            harmony.PatchAll();
        }

        [HarmonyPatch(typeof(BaseTool))]
        [HarmonyPatch("OnHitObject")]
        public class BaseTool_OnHitObject_Patch
        {
            public static void Postfix(BaseTool __instance, GameObject target)
            {
                if (__instance.GetType() == typeof(BuilderTool))
                {
                    if (target.GetComponent<Pickupable>()?.GetTechType() == TechType.Wreck)
                    {
                        if (__instance.electronic)
                        {
                            Inventory.main.GiveItem(AddItemsToInventory(baseBuilderV2TechType, 1));
                        }
                        else
                        {
                            ErrorMessage.AddMessage("This tool requires a battery.");
                        }
                    }
                    else
                    {
                        if (__instance.electronic)
                        {
                            Inventory.main.GiveItem(AddItemsToInventory(baseBuilderV3TechType, Random.Range(1, 4)));
                        }
                        else
                        {
                            Inventory.main.GiveItem(AddItemsToInventory(TechType.Builder, 1));
                        }
                    }
                }
            }

            private static Pickupable.AdditionalPickingSettings AddItemsToInventory(TechType techType, int count)
            {
                return new Pickupable.AdditionalPickingSettings
                {
                    forPDA = true,
                    destroyOnPickup = true,
                    pickupSound = null,
                    playPickupSound = true,
                    slotFlags = InventorySlotType.General,
                    allowCopy = false,
                    amount = count,
                    techType = techType
                };
            }
        }

        [HarmonyPatch(typeof(Builder))]
        [HarmonyPatch("GetPrefabsForTechType")]
        public class Builder_GetPrefabsForTechType_Patch
        {
            public static void Postfix(TechType techType, ref int __result)
            {
                if (techType == baseBuilderV2TechType || techType == baseBuilderV3TechType)
                {
                    __result = 1;
                }
            }
        }

        [HarmonyPatch(typeof(Builder))]
        public class Builder_GetConstructable_Patch
        {
            public static void Postfix(TechType techType, ref Constructable __result)
            {
                if (techType == baseBuilderV2TechType || techType == baseBuilderV3TechType)
                {
                    __result = new Constructable(TechType.Builder, new string[] { "MultiTools", "Advanced Base Building" }, "Constructable/Deployables/BaseBuilder", true, null);
                }
            }
        }

        [HarmonyPatch(typeof(CrafterLogic))]
        public class CrafterLogic_GetFabricatorTab_Patch
        {
            public static void Postfix(CrafterLogic __instance, CraftData.DataType dataType, ref int __result)
            {
                if (dataType == CraftData.DataType.Tools && __instance.name == "Fabricator" && __instance.techType == TechType.Fabricator)
                {
                    __result = __instance.AddTab("Advanced Tools", baseBuilderV2TechType, baseBuilderV3TechType);
                }
            }
        }
    }
}
"

3. MultiTools.cs Wzór kodu:
"
 using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace MultiTools
{
    public static class MultiTools
    {
        public static void Load()
        {
            // Tutaj można dodać kod do inicjalizacji pluginu
        }

        public static void Unload()
        {
            // Tutaj można dodać kod do wyłączenia pluginu
        }

        public static void Patch()
        {
            // Dodanie nowych urządzeń do fabrykatora
            TechTypeBuilder.AddTechType("BaseBuilderToolV2", "Base Builder V2", "A device used to build bases.", (int)TechGroup.Resources, (int)TechCategory.Tools);
            CraftDataHandler.SetTechData(TechType.BaseBuilderToolV2, new TechData()
            {
                craftAmount = 1,
                Ingredients = new List<Ingredient>()
                {
                    new Ingredient(TechType.Titanium, 2),
                    new Ingredient(TechType.Lubricant, 1),
                    new Ingredient(TechType.Silicone, 1),
                }
            });

            TechTypeBuilder.AddTechType("BaseBuilderToolV3", "Base Builder V3", "An advanced device used to build bases.", (int)TechGroup.Resources, (int)TechCategory.Tools);
            CraftDataHandler.SetTechData(TechType.BaseBuilderToolV3, new TechData()
            {
                craftAmount = 1,
                Ingredients = new List<Ingredient>()
                {
                    new Ingredient(TechType.Titanium, 2),
                    new Ingredient(TechType.WiringKit, 1),
                    new Ingredient(TechType.Silicone, 1),
                    new Ingredient(TechType.Diamond, 1),
                }
            });

            // Dodanie nowych metod do obsługi urządzeń
            CraftDataHandler.SetItemSize(TechType.BaseBuilderToolV2, new Vector2int(2, 2));
            CraftDataHandler.SetItemSize(TechType.BaseBuilderToolV3, new Vector2int(2, 2));
            CraftDataHandler.SetEquipmentType(TechType.BaseBuilderToolV2, EquipmentType.Hand);
            CraftDataHandler.SetEquipmentType(TechType.BaseBuilderToolV3, EquipmentType.Hand);

            // Dodanie metod do obsługi upuszczania materiałów
            MethodInfo dropItemAtMethodV2 = typeof(BaseBuilderV2).GetMethod("DropItemAt", BindingFlags.Instance | BindingFlags.NonPublic);
            CraftDataHandler.AddToGroup(TechGroup.Resources, TechCategory.Tools, TechType.BaseBuilderToolV2);
            CraftDataHandler.SetHarvestType(TechType.BaseBuilderToolV2, HarvestType.Normal);
            CraftDataHandler.SetInteractDistance(TechType.BaseBuilderToolV2, 5f);
            CraftDataHandler.SetEquipmentAction(TechType.BaseBuilderToolV2, new EquipmentAction(dropItemAtMethodV2, new LiveMixinData(0f), new UseFirstAidData(1f), EquipmentActions.Default));
            CraftDataHandler.AddToSubCategory(TechCategory.Tools, TechType.BaseBuilderToolV2);

            MethodInfo dropItemAtMethodV3 = typeof(BaseBuilderV3).GetMethod("DropItemAt", BindingFlags.Instance | BindingFlags.NonPublic);
            CraftDataHandler.AddToGroup(TechGroup.Resources, TechCategory.Tools, TechType.BaseBuilderToolV3);
            CraftDataHandler.SetHarvestType(TechType.BaseBuilderToolV3, HarvestType.Normal);
            CraftDataHandler.SetInteractDistance(TechType.BaseBuilderToolV3, 5f);
            CraftDataHandler.SetEquipmentAction(TechType.BaseBuilderTool
            CraftDataHandler.SetItemSize(TechType.BaseBuilderToolV2, new Vector2int(2, 2));
            CraftDataHandler.SetItemSize(TechType.BaseBuilderToolV3, new Vector2int(3, 3));

            CraftDataHandler.SetEquipmentType(TechType.BaseBuilderToolV2, EquipmentType.Hand);
            CraftDataHandler.SetEquipmentType(TechType.BaseBuilderToolV3, EquipmentType.Hand);

            CraftDataHandler.AddToGroup(TechGroup.Resources, TechCategory.Tools, TechType.BaseBuilderToolV2);
            CraftDataHandler.AddToGroup(TechGroup.Resources, TechCategory.Tools, TechType.BaseBuilderToolV3);

            var ab = Assembly.GetExecutingAssembly();
            var abName = ab.GetName().Name;
            var abVersion = ab.GetName().Version;
            var abDescription = ab.GetCustomAttribute<AssemblyDescriptionAttribute>()?.Description;

            Debug.Log($"{abName} v{abVersion} - {abDescription} - loaded.");
        }
    }

    public class BaseBuilderToolV2 : ToolAction
    {
        public override void OnToolUseAnim(GUIHand hand)
        {
            // Kod do obsługi urządzenia "Base Builder V2"
            Inventory.main.container.RemoveItem(TechType.Titanium, 2);
            Inventory.main.container.RemoveItem(TechType.Lubricant, 1);
            Inventory.main.container.RemoveItem(TechType.Silicone, 1);
            Debug.Log("Base Builder V2 used.");
        }
    }

    public class BaseBuilderToolV3 : ToolAction
    {
        public override void OnToolUseAnim(GUIHand hand)
        {
            // Kod do obsługi urządzenia "Base Builder V3"
            Inventory.main.container.RemoveItem(TechType.Titanium, 2);
            Inventory.main.container.RemoveItem(TechType.WiringKit, 1);
            Inventory.main.container.RemoveItem(TechType.Silicone, 1);
            Inventory.main.container.RemoveItem(TechType.Diamond, 1);
            Debug.Log("Base Builder V3 used.");
        }
    }
} 
"

4. BepInEx.csproj Wzór kodu:
"
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>netstandard2.0</TargetFramework>
    <AssemblyName>BepInEx</AssemblyName>
    <OutputType>Library</OutputType>
    <AppendTargetFrameworkToOutputPath>false</AppendTargetFrameworkToOutputPath>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="**\*.cs" Exclude="Properties\**\*.cs" />
  </ItemGroup>
  <ItemGroup>
    <Reference Include="UnityEngine">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.CoreModule">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.CoreModule.dll</HintPath>
    </Reference>
    <Reference Include="UnityEngine.UI">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\UnityEngine.UI.dll</HintPath>
    </Reference>
    <Reference Include="Assembly-CSharp">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\Assembly-CSharp.dll</HintPath>
    </Reference>
    <Reference Include="Assembly-CSharp-firstpass">
      <HintPath>..\Subnautica\Subnautica_Data\Managed\Assembly-CSharp-firstpass.dll</HintPath>
    </Reference>
    <Reference Include="BepInEx">
      <HintPath>..\BepInEx\BepInEx.dll</HintPath>
    </Reference>
  </ItemGroup>
  <ItemGroup>
    <PackageReference Include="BepInEx" Version="5.4.4" />
  </ItemGroup>
</Project>
"

5. BaseBuilderToolV2.cs Wzór kodu:
"
    public static class BaseBuilderToolV2_Patch
    {
        [HarmonyPatch(typeof(HoverPreview))]
        [HarmonyPatch("OnHover")]
        public static class HoverPreview_OnHover_Patch
        {
            public static void Prefix(HoverPreview __instance)
            {
                if (__instance.name.Contains("HabitatBuilder") && Inventory.main != null)
                {
                    PDA pda = Inventory.main.GetComponentInParent<PDA>();
                    if (pda != null)
                    {
                        if (pda.isInUse && __instance.gameObject.GetComponentInParent<Constructable>() == null)
                        {
                            __instance.gameObject.AddComponent<Constructable>();
                            __instance.gameObject.AddComponent<BaseBuilderToolV3>();
                        }
                    }
                }
            }
        }
        
        public class BaseBuilderToolV2 : MonoBehaviour
        {
            public static bool isPlacing = false;
            public static bool inBaseMode = false;
            public static bool inDeconstructMode = false;

            private static bool readyToDeploy;
            private static bool haveRequiredMaterials;
            private static BaseBuilderV2.Mode buildMode;
            private static BaseBuilderV2.Buildable buildable;
            private static TechType[] allowedPlaceModes = new TechType[]
            {
                TechType.BaseFoundation, TechType.BaseFloor, TechType.BaseWall, TechType.BaseCeiling, TechType.BaseTube
            };
            
            private static List<TechType> deconstructableTechTypes = new List<TechType>
            {
                TechType.BaseFoundation, TechType.BaseFloor, TechType.BaseWall, TechType.BaseCeiling, TechType.BaseTube,
                TechType.Hatch, TechType.Moonpool, TechType.ScannerRoom, TechType.GlassDome, TechType.MultipurposeRoom,
                TechType.Reinforcement, TechType.ThermalPlant, TechType.PowerTransmitter, TechType.PowerGeneratorBioReactor,
                TechType.NuclearReactor, TechType.WaterFiltrationMachine, TechType.LargeRoom, TechType.ExteriorWallWindow,
                TechType.PipeSurface, TechType.PipeWallMounted, TechType.PipeLadder, TechType.PipeJunction,
                TechType.PipeHorizontal, TechType.PipeVertical, TechType.PipeValve, TechType.FiltrationMachine,
                TechType.Ladder, TechType.PrecursorDungeonWall, TechType.MarineSnow, TechType.Shelf, TechType.PropulsionCannon,
                TechType.CyclopsHullArmorModule, TechType.CyclopsDecoyTube, TechType.CyclopsFireSuppressionModule,
                TechType.CyclopsSonarModule, TechType.CyclopsSeamothRepairModule, TechType.CyclopsShieldModule,
                TechType.CyclopsThermalReactorModule, TechType.CyclopsPowerUpgradeModule, TechType.CyclopsBridgeUpgradeModule,
                TechType.CyclopsSpeedUpgradeModule, TechType.CyclopsSilentRunningUpgradeModule, TechType.CyclopsHullModule1,
                TechType.CyclopsHullModule2, TechType.CyclopsHullModule3, TechType.CyclopsEnergyEfficiencyModule,
                TechType.CyclopsSonarModule, TechType.CyclopsDecoyModule, TechType.CyclopsSeamothModule, TechType.ExosuitDrillArmModule,
                TechType.ExosuitPropulsionArmModule, TechType.ExosuitGrapplingArmModule, TechType.Exosuit
        private void CheckForValidTargets()
        {
            if (!isInRadius)
            {
                target = null;
                return;
            }

            // Filter out invalid targets and get closest one
            float closestDist = maxDistance;
            for (int i = targets.Count - 1; i >= 0; i--)
            {
                Target t = targets[i];
                if (!IsValidTarget(t, out float dist))
                {
                    targets.RemoveAt(i);
                }
                else if (dist < closestDist)
                {
                    closestDist = dist;
                    target = t;
                }
            }

            if (target == null && targets.Count > 0)
            {
                target = targets[0];
            }
        }

        private bool IsValidTarget(Target t, out float dist)
        {
            if (!t)
            {
                dist = 0f;
                return false;
            }

            Vector3 tPos = t.transform.position;
            if (!t.gameObject.activeSelf || Vector3.Distance(transform.position, tPos) > maxDistance)
            {
                dist = 0f;
                return false;
            }

            dist = Vector3.Distance(transform.position, tPos);
            return true;
        }

        private void OnDrawGizmos()
        {
            if (!showGizmos)
            {
                return;
            }

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, maxDistance);
        }
    }
}
"

6. BaseBuilderToolV2Config.cs Wzór kodu:
"
 using SMLHelper.V2.Json;
using SMLHelper.V2.Options.Attributes;

namespace MultitoolsMod.Configuration
{
    [Menu("Multitools", "Builder V3 Config")]
    public class BaseBuilderToolV2Config : ConfigFile
    {
        [Slider("Max Distance", 0, 100)]
        public float MaxDistance = 10f;

        [Toggle("Enable Precision Placement")]
        public bool EnablePrecisionPlacement = false;

        [Toggle("Enable Instant Build")]
        public bool EnableInstantBuild = false;

        [Toggle("Enable Fast Build")]
        public bool EnableFastBuild = false;

        [Toggle("Enable Vertical Snap")]
        public bool EnableVerticalSnap = false;

        [Toggle("Enable Horizontal Snap")]
        public bool EnableHorizontalSnap = false;

        [Slider("Horizontal Snap Degrees", 0, 360)]
        public float HorizontalSnapDegrees = 45f;

        [Toggle("Enable Random Build Angle")]
        public bool EnableRandomBuildAngle = false;

        [Slider("Max Random Angle", 0, 360)]
        public float MaxRandomAngle = 10f;

        [Toggle("Enable Quick Switch")]
        public bool EnableQuickSwitch = false;

        [Toggle("Enable Rotate Button")]
        public bool EnableRotateButton = false;

        [Toggle("Enable Demolish Button")]
        public bool EnableDemolishButton = false;
    }
}
"

7. BaseBuilderToolV3.cs Wzór kodu:
"
      public static class BaseBuilderToolV3_Patch
    {
        [HarmonyPatch(typeof(HoverPreview))]
        [HarmonyPatch("OnHover")]
        public static class HoverPreview_OnHover_Patch
        {
            public static void Prefix(HoverPreview __instance)
            {
                if (__instance.name.Contains("HabitatBuilder") && Inventory.main != null)
                {
                    PDA pda = Inventory.main.GetComponentInParent<PDA>();
                    if (pda != null)
                    {
                        if (pda.isInUse && __instance.gameObject.GetComponentInParent<Constructable>() == null)
                        {
                            __instance.gameObject.AddComponent<Constructable>();
                            __instance.gameObject.AddComponent<BaseBuilderToolV3>();
                        }
                    }
                }
            }
        }
        
        public class BaseBuilderToolV3 : MonoBehaviour
        {
            public static bool isPlacing = false;
            public static bool inBaseMode = false;
            public static bool inDeconstructMode = false;

            private static bool readyToDeploy;
            private static bool haveRequiredMaterials;
            private static BaseBuilderV3.Mode buildMode;
            private static BaseBuilderV3.Buildable buildable;
            private static TechType[] allowedPlaceModes = new TechType[]
            {
                TechType.BaseFoundation, TechType.BaseFloor, TechType.BaseWall, TechType.BaseCeiling, TechType.BaseTube
            };
            
            private static List<TechType> deconstructableTechTypes = new List<TechType>
            {
                TechType.BaseFoundation, TechType.BaseFloor, TechType.BaseWall, TechType.BaseCeiling, TechType.BaseTube,
                TechType.Hatch, TechType.Moonpool, TechType.ScannerRoom, TechType.GlassDome, TechType.MultipurposeRoom,
                TechType.Reinforcement, TechType.ThermalPlant, TechType.PowerTransmitter, TechType.PowerGeneratorBioReactor,
                TechType.NuclearReactor, TechType.WaterFiltrationMachine, TechType.LargeRoom, TechType.ExteriorWallWindow,
                TechType.PipeSurface, TechType.PipeWallMounted, TechType.PipeLadder, TechType.PipeJunction,
                TechType.PipeHorizontal, TechType.PipeVertical, TechType.PipeValve, TechType.FiltrationMachine,
                TechType.Ladder, TechType.PrecursorDungeonWall, TechType.MarineSnow, TechType.Shelf, TechType.PropulsionCannon,
                TechType.CyclopsHullArmorModule, TechType.CyclopsDecoyTube, TechType.CyclopsFireSuppressionModule,
                TechType.CyclopsSonarModule, TechType.CyclopsSeamothRepairModule, TechType.CyclopsShieldModule,
                TechType.CyclopsThermalReactorModule, TechType.CyclopsPowerUpgradeModule, TechType.CyclopsBridgeUpgradeModule,
                TechType.CyclopsSpeedUpgradeModule, TechType.CyclopsSilentRunningUpgradeModule, TechType.CyclopsHullModule1,
                TechType.CyclopsHullModule2, TechType.CyclopsHullModule3, TechType.CyclopsEnergyEfficiencyModule,
                TechType.CyclopsSonarModule, TechType.CyclopsDecoyModule, TechType.CyclopsSeamothModule, TechType.ExosuitDrillArmModule,
                TechType.ExosuitPropulsionArmModule, TechType.ExosuitGrapplingArmModule, TechType.Exosuit
        private void CheckForValidTargets()
        {
            if (!isInRadius)
            {
                target = null;
                return;
            }

            // Filter out invalid targets and get closest one
            float closestDist = maxDistance;
            for (int i = targets.Count - 1; i >= 0; i--)
            {
                Target t = targets[i];
                if (!IsValidTarget(t, out float dist))
                {
                    targets.RemoveAt(i);
                }
                else if (dist < closestDist)
                {
                    closestDist = dist;
                    target = t;
                }
            }

            if (target == null && targets.Count > 0)
            {
                target = targets[0];
            }
        }

        private bool IsValidTarget(Target t, out float dist)
        {
            if (!t)
            {
                dist = 0f;
                return false;
            }

            Vector3 tPos = t.transform.position;
            if (!t.gameObject.activeSelf || Vector3.Distance(transform.position, tPos) > maxDistance)
            {
                dist = 0f;
                return false;
            }

            dist = Vector3.Distance(transform.position, tPos);
            return true;
        }

        private void OnDrawGizmos()
        {
            if (!showGizmos)
            {
                return;
            }

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, maxDistance);
        }
    }
}
"

8. BaseBuilderToolV3Config.cs Wzór kodu:
"
using SMLHelper.V2.Json;
using SMLHelper.V2.Options.Attributes;

namespace MultitoolsMod.Configuration
{
    [Menu("Multitools", "Builder V3 Config")]
    public class BaseBuilderToolV3Config : ConfigFile
    {
        [Slider("Max Distance", 0, 100)]
        public float MaxDistance = 10f;

        [Toggle("Enable Precision Placement")]
        public bool EnablePrecisionPlacement = false;

        [Toggle("Enable Instant Build")]
        public bool EnableInstantBuild = false;

        [Toggle("Enable Fast Build")]
        public bool EnableFastBuild = false;

        [Toggle("Enable Vertical Snap")]
        public bool EnableVerticalSnap = false;

        [Toggle("Enable Horizontal Snap")]
        public bool EnableHorizontalSnap = false;

        [Slider("Horizontal Snap Degrees", 0, 360)]
        public float HorizontalSnapDegrees = 45f;

        [Toggle("Enable Random Build Angle")]
        public bool EnableRandomBuildAngle = false;

        [Slider("Max Random Angle", 0, 360)]
        public float MaxRandomAngle = 10f;

        [Toggle("Enable Quick Switch")]
        public bool EnableQuickSwitch = false;

        [Toggle("Enable Rotate Button")]
        public bool EnableRotateButton = false;

        [Toggle("Enable Demolish Button")]
        public bool EnableDemolishButton = false;
    }
}
"

9. BuilderV2.cs Wzór kodu:
"
 using System;
using SMLHelper.V2.Json;
using SMLHelper.V2.Options.Attributes;
using SMLHelper.V2.Handlers;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace BaseBuilderToolV2
{
    public static class BaseBuilderToolV2
    {
        public static void Patch()
        {
            try
            {
                CraftDataHandler.AddToTechFabricator(TechType.SeaMoth, TechType.Builder);
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }
    }

    public class BaseBuilderV2 : MonoBehaviour
    {
        private Inventory inventory;

        void Start()
        {
            inventory = GetComponent<Inventory>();
        }

        public void DropItemAt(int index, Vector3 position, Quaternion rotation, Vector3 velocity)
        {
            inventory.RemoveItem(index, true);
            CraftData.Ingredient ingredient = new CraftData.Ingredient() { techType = TechType.Titanium, amount = 1 };
            GameObject titanium = CraftData.InstantiateFromPrefab(ingredient.techType);
            titanium.transform.position = position;
            titanium.transform.rotation = rotation;
            Rigidbody rigidBody = titanium.GetComponent<Rigidbody>();
            rigidBody.velocity = velocity;
        }
    }
}

"

910 BuilderV3.cs Wzór kodu:
"
 using System;
using SMLHelper.V2.Json;
using SMLHelper.V2.Options.Attributes;
using SMLHelper.V2.Handlers;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace BaseBuilderToolV3
{
    public static class BaseBuilderToolV3
    {
        public static void Patch()
        {
            try
            {
                CraftDataHandler.AddToTechFabricator(TechType.SeaMoth, TechType.Builder);
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }
    }

    public class BaseBuilderV3 : MonoBehaviour
    {
        private Inventory inventory;

        void Start()
        {
            inventory = GetComponent<Inventory>();
        }

        public void DropItemAt(int index, Vector3 position, Quaternion rotation, Vector3 velocity)
        {
            inventory.RemoveItem(index, true);
            CraftData.Ingredient ingredient = new CraftData.Ingredient() { techType = TechType.Titanium, amount = 1 };
            GameObject titanium = CraftData.InstantiateFromPrefab(ingredient.techType);
            titanium.transform.position = position;
            titanium.transform.rotation = rotation;
            Rigidbody rigidBody = titanium.GetComponent<Rigidbody>();
            rigidBody.velocity = velocity;
        }
    }
}
"

11 LanguageHandler.cs Wzór kodu:
"
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace MultitoolsMod
{
    public class LanguageHandler
    {
        private static readonly Dictionary<string, string> Translations = new Dictionary<string, string>();

        public static void LoadTranslations(string languageCode)
        {
            string filePath = Path.Combine(Main.ModDirectory, $"translations_{languageCode}.txt");

            if (!File.Exists(filePath))
            {
                Debug.Log($"Translation file not found: {filePath}");
                return;
            }

            Translations.Clear();

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                if (string.IsNullOrEmpty(line)) continue;

                string[] parts = line.Split('=');

                if (parts.Length != 2) continue;

                string key = parts[0].Trim();
                string value = parts[1].Trim();

                Translations[key] = value;
            }

            Debug.Log($"Loaded {Translations.Count} translations for language {languageCode}");
        }

        public static string GetTranslation(string key)
        {
            if (Translations.TryGetValue(key, out string value))
            {
                return value;
            }

            return key;
        }
    }
}
"

12 Main.cs Wzór kodu:
"
using BepInEx;
using UnityEngine;

[BepInPlugin("com.example.multitools", "MultiTools", "1.0.0")]
public class Main : BaseUnityPlugin
{
    void Awake()
    {
        Debug.Log("MultiTools plugin loaded!");
    }
}
"

13 ModConfig.cs Wzór kodu:
"
using BepInEx.Configuration;
using UnityEngine;

namespace MultitoolsMod
{
    public static class ModConfig
    {
        public static ConfigEntry<bool> V2Enabled;
        public static ConfigEntry<bool> V3Enabled;
        public static ConfigEntry<bool> BuildInSurvival;
        public static ConfigEntry<bool> BuildInFreedom;
        public static ConfigEntry<bool> BuildInCreative;
        public static ConfigEntry<bool> BuildInHardcore;

        public static void Init(ConfigFile config)
        {
            V2Enabled = config.Bind("BaseBuilderToolV2", "Enabled", true, "Enable/disable the Base Builder Tool V2");
            V3Enabled = config.Bind("BaseBuilderToolV3", "Enabled", true, "Enable/disable the Base Builder Tool V3");
            BuildInSurvival = config.Bind("Builder", "BuildInSurvival", true, "Allow building in Survival mode");
            BuildInFreedom = config.Bind("Builder", "BuildInFreedom", true, "Allow building in Freedom mode");
            BuildInCreative = config.Bind("Builder", "BuildInCreative", true, "Allow building in Creative mode");
            BuildInHardcore = config.Bind("Builder", "BuildInHardcore", true, "Allow building in Hardcore mode");
        }
    }
}
"

14 ModEnums.cs Wzór kodu:
"
public enum SomeEnum
{
    Value1,
    Value2,
    Value3
}

public static class ModEnums
{
    public static SomeEnum CurrentValue;
}
"

15 ModHooks.cs Wzór kodu:
"
using System;
using System.Collections.Generic;
using Harmony;
using UnityEngine;

public class ModHooks
{
    private static readonly List<Action> _onLoadActions = new List<Action>();
    private static readonly List<Action> _onSaveActions = new List<Action>();
    private static readonly List<Action> _onUpdateActions = new List<Action>();
    private static readonly List<Action> _onGUIActions = new List<Action>();
    private static readonly List<Action> _onApplicationQuitActions = new List<Action>();

    public static void AddOnLoadAction(Action action)
    {
        if (action != null)
        {
            _onLoadActions.Add(action);
        }
        else
        {
            Debug.Log("Tried to add null OnLoad action.");
        }
    }

    public static void AddOnSaveAction(Action action)
    {
        if (action != null)
        {
            _onSaveActions.Add(action);
        }
        else
        {
            Debug.Log("Tried to add null OnSave action.");
        }
    }

    public static void AddOnUpdateAction(Action action)
    {
        if (action != null)
        {
            _onUpdateActions.Add(action);
        }
        else
        {
            Debug.Log("Tried to add null OnUpdate action.");
        }
    }

    public static void AddOnGUIAction(Action action)
    {
        if (action != null)
        {
            _onGUIActions.Add(action);
        }
        else
        {
            Debug.Log("Tried to add null OnGUI action.");
        }
    }

    public static void AddOnApplicationQuitAction(Action action)
    {
        if (action != null)
        {
            _onApplicationQuitActions.Add(action);
        }
        else
        {
            Debug.Log("Tried to add null OnApplicationQuit action.");
        }
    }

    [HarmonyPatch(typeof(GameManager))]
    [HarmonyPatch("Load")]
    public class Load_Patch
    {
        [HarmonyPostfix]
        public static void Postfix()
        {
            foreach (var action in _onLoadActions)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Debug.Log($"Error executing OnLoad action: {ex}");
                }
            }
        }
    }

    [HarmonyPatch(typeof(SaveLoadManager))]
    [HarmonyPatch("Save")]
    public class Save_Patch
    {
        [HarmonyPostfix]
        public static void Postfix()
        {
            foreach (var action in _onSaveActions)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Debug.Log($"Error executing OnSave action: {ex}");
                }
            }
        }
    }

    [HarmonyPatch(typeof(uGUI_MainMenu))]
    [HarmonyPatch("Update")]
    public class Update_Patch
    {
        [HarmonyPostfix]
        public static void Postfix()
        {
            foreach (var action in _onUpdateActions)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Debug.Log($"Error executing OnUpdate action: {ex}");
                }
            }
        }
    }

    [HarmonyPatch(typeof(uGUI))]
    [HarmonyPatch("Update")]
    public class GUI_Patch
    {
        [HarmonyPostfix]
        public static void Postfix()
        {
            foreach (var action in _onGUIActions)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Debug.Log($"Error executing OnGUI action: {ex}");
                }
            }
        }
    }

    [HarmonyPatch(typeof(Application))]
    [HarmonyPatch("Quit")]
    public class Quit_Patch
    {
        [HarmonyPrefix]
        public static void Prefix()
        {
            foreach (var action in _onApplicationQuitActions)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Debug.Log($"Error executing OnApplicationQuit action: {ex}");
                }
            }
        }
    }
}
"

16 BaseBuilderToolV2.cfg Wzór kodu:
"
## BaseBuilderToolV2 Configuration File ##

[General]

## Enable/disable the Base Builder Tool V2
# Setting type: Boolean
# Default value: true
Enabled=true

[Builder]

## Allow building in Survival mode
# Setting type: Boolean
# Default value: true
BuildInSurvival=true

## Allow building in Freedom mode
# Setting type: Boolean
# Default value: true
BuildInFreedom=true

## Allow building in Creative mode
# Setting type: Boolean
# Default value: true
BuildInCreative=true

## Allow building in Hardcore mode
# Setting type: Boolean
# Default value: true
BuildInHardcore=true

"

17 BaseBuilderToolV3.cfg Wzór kodu:
"
## BaseBuilderToolV3 Configuration File ##

[General]

## Enable/disable the Base Builder Tool V3
# Setting type: Boolean
# Default value: true
Enabled=true

[Builder]

## Allow building in Survival mode
# Setting type: Boolean
# Default value: true
BuildInSurvival=true

## Allow building in Freedom mode
# Setting type: Boolean
# Default value: true
BuildInFreedom=true

## Allow building in Creative mode
# Setting type: Boolean
# Default value: true
BuildInCreative=true

## Allow building in Hardcore mode
# Setting type: Boolean
# Default value: true
BuildInHardcore=true


"

18 Multitools.cfg Wzór kodu:
"
[MultiTools]
##General Settings
##Set to true to enable debug logging
Debug = false
##Set to true to enable the MultiTools mod
EnableMultiTools = true
##The keybind to activate the MultiTools menu
MenuKey = F8

##Builder Settings
##Set to true to enable the Builder
EnableBuilder = true
##The keybind to activate the Builder tool
BuilderKey = F9
##The maximum distance at which the Builder tool can place objects
BuilderMaxDistance = 10.0
##The maximum number of objects that can be placed with the Builder tool at once
BuilderMaxObjects = 10

##Scanner Settings
##Set to true to enable the Scanner
EnableScanner = true
##The keybind to activate the Scanner tool
ScannerKey = F10
##The maximum distance at which the Scanner can detect objects
ScannerMaxDistance = 100.0
##The types of objects that the Scanner can detect
ScannerObjectTypes = "Metal, Mineral, Creature"

##Drill Settings
##Set to true to enable the Drill
EnableDrill = true
##The keybind to activate the Drill tool
DrillKey = F11
##The maximum distance at which the Drill can mine resources
DrillMaxDistance = 10.0
##The types of resources that the Drill can mine
DrillResourceTypes = "Limestone, Sandstone, Shale"

##Language Settings
##Set the language code for the mod. Available languages: English, French, German, Italian, Japanese, Korean, Polish, Portuguese-Brazil, Russian, Simplified Chinese, Spanish-Mexico, Turkish
Language = "English"
"